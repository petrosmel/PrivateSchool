package individualprojectpartb;

import java.sql.*;
import java.util.Scanner;

public class IndividualProjectPartB {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome user!");
        mainMenu();
    }

    public static void mainMenu() {
        System.out.println("==================================================================================");
        System.out.println("1. Preview data");  // View database data.
        System.out.println("2. Insert data");  // Insert existing data.
        System.out.println("3. Exit");  // Exit application.
        System.out.println("==================================================================================");
        System.out.print("\n" + "Choose from 1 to 3: ");
        String menuInput = sc.next();
        switch (menuInput) {
            case ("1"):
                selectMenu();
                break;
            case ("2"):
                insertMenu();
                break;
            case ("3"):
                System.out.println("Goodbye. See you soon!");
                System.exit(0);
                break;
            default:
                System.out.println("!!!!!  " + menuInput + " is not a valid entry. Please try again.  !!!!!");
                mainMenu();

        }
    }

    public static void selectMenu() {

        System.out.println("==================================================================================");
        System.out.println("1. A list of all the courses " + "\n"
                + "2. A list of all the trainers" + "\n"
                + "3. A list of all the students" + "\n"
                + "4. A list of all the assigments" + "\n"
                + "5. All the students per course" + "\n"
                + "6. All the trainers per course " + "\n"
                + "7. All the assignments per course " + "\n"
                + "8. All the assignments per course per student" + "\n"
                + "9. A list of students that belong to more than one courses" + "\n"
                + "10. Back");
        System.out.println("==================================================================================");
        System.out.print("\n" + "Choose from 1 to 10: ");
        String menuInput = sc.next();
        switch (menuInput) {
            case ("1"):
            case ("2"):
            case ("3"):
            case ("4"):
            case ("5"):
            case ("6"):
            case ("7"):
            case ("8"):
            case ("9"):
                qSelect(menuInput);
                break;
            case ("10"):
                mainMenu();
                break;
            default:
                System.out.println("!!!!!  " + menuInput + " is not a valid entry. Please try again.  !!!!!");
                selectMenu();

        }
    }

    public static void insertMenu() {

        System.out.println("==================================================================================");
        System.out.println("1. Insert new trainers" + "\n"
                + "2. Insert new students" + "\n"
                + "3. Insert new courses " + "\n"
                + "4. Insert new assignments " + "\n"
                + "5. Combine students with course " + "\n"
                + "6. Combine trainers with course" + "\n"
                + "7. Back");
        System.out.println("==================================================================================");
        System.out.print("\n" + "Choose from 1 to 7: ");
        String menuInput = sc.next();
        switch (menuInput) {
            case ("1"):
            case ("2"):
            case ("3"):
            case ("4"):
            case ("5"):
            case ("6"):
                qInsert(menuInput);
            case ("7"):
                mainMenu();
                break;

            default:
                System.out.println("!!!!!  " + menuInput + " is not a valid entry. Please try again.  !!!!!");
                insertMenu();
        }

    }

    public static void qSelect(String menuInput) {
        //We create an Array of strings as input to the following method
        String[] selectList = {
            /*q1*/"SELECT * FROM `individualprojectpartb`.`course`;",
            /*q2*/ "SELECT * FROM `individualprojectpartb`.`trainer`;",
            /*q3*/ "SELECT * FROM `individualprojectpartb`.`student`;",
            /*q4*/ "SELECT * FROM `individualprojectpartb`.`assigment`;",
            /*q5*/ "SELECT `course`.`title`, `course`.`stream`, `course`.`type`,  `student`.`firstname`, `student`.`lastname`\n"
            + "FROM `student`\n"
            + "JOIN `studentscourses` ON `studentscourses`.`stid`=`student`.`id`\n"
            + "JOIN `course` ON `studentscourses`.`cid` = `course`.`id`\n"
            + "ORDER BY `course`.`stream`, `course`.`type`;",
            /*q6*/ "SELECT `course`.`title`, `course`.`stream`, `course`.`typse`,  `trainer`.`firstname`, `trainer`.`lastname`\n"
            + "FROM `trainer`\n"
            + "JOIN `trainerscourses` ON `trainerscourses`.`trid`=`trainer`.`id`\n"
            + "JOIN `course` ON `trainerscourses`.`cid` = `course`.`id`\n"
            + "ORDER BY `course`.`stream`, `course`.`type`;",
            /*q7*/ "SELECT `course`.`title`, `course`.`stream`, `course`.`type`,  `assigment`.`title`\n"
            + "FROM `assigment`\n"
            + "JOIN `course` ON `assigment`.`course`=`course`.`id`\n"
            + "ORDER BY `course`.`stream`, `course`.`type`;",
            /*q8*/ "SELECT student.firstname, student.lastname, CONCAT(`course`.`title`,\" \", `course`.`stream`,\" \", `course`.`type`) AS course, assigment.title \n"
            + "FROM course\n"
            + "INNER JOIN assigment ON assigment.course=course.id\n"
            + "INNER JOIN studentscourses ON studentscourses.id=stid\n"
            + "INNER JOIN student ON studentscourses.stid=student.id\n"
            + "ORDER BY student.firstname, student.lastname;",
            /*q9*/ "SELECT * FROM (\n"
            + "SELECT COUNT(`cid`) AS 'number of courses', `student`.`firstname`, `student`.`lastname`\n"
            + "FROM `student`\n"
            + "INNER JOIN `studentscourses` ON `student`.`id`=`studentscourses`.`stid`\n"
            + "INNER JOIN `course` ON `course`.`id`=`studentscourses`.`cid` \n"
            + "GROUP BY `student`.`firstname`, `student`.`lastname`\n"
            + ") AS TEMPRESULT\n"
            + "WHERE  `number of courses`>1;"};
        try {

            //Get Connection to localhost server
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/individualprojectpartb?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Athens", "root", "1234");

            //Create Statment
            Statement st = con.createStatement();

            //Execute SQL querry
            int i = Integer.parseInt(menuInput);
            ResultSet rs = st.executeQuery(selectList[i - 1]);

            //Result print We use metadata to get further information from the table
            ResultSetMetaData md = rs.getMetaData();
            int colNumber = md.getColumnCount();
            while (rs.next()) {

                for (int j = 1; j <= colNumber; j++) {
                    String columnName = md.getColumnName(j);
                    System.out.println(columnName + " " + rs.getString(j));
                }
                System.out.println("-------------------------");
            }
            // Closing connection to database
            rs.close();
            st.close();
            con.close();
            selectMenu();
        } catch (SQLException ex) {
            System.out.println("Exception connecting to database:" + ex + "\n");
            mainMenu();
        }
    }

    public static void qInsert(String menuInput) {
        //We create an Array of strings as input to the following method
        String[] insertList = {
            /*q1*/ "INSERT INTO `individualprojectpartb`.`trainer` (`firstname`,`lastname`) VALUES (",
            /*q2*/ "INSERT INTO `individualprojectpartb`.`student` (`firstname`,`lastname`, `dateofbirth`,`tuitionfees`) VALUES (",
            /*q3*/ "INSERT INTO `individualprojectpartb`.`course` (`title`, `stream`, `type`, `startdate`, `enddate`) VALUES (",
            /*q4*/ "INSERT INTO `individualprojectpartb`.`assigment` (`title`, `description`,`subdatetime`,`oralmark`,`totalmark`,`course`) VALUES (",
            /*q5*/ "INSERT INTO `individualprojectpartb`.`studentscourses` (`stid`, `cid`) VALUES (",
            /*q6*/ "INSERT INTO `individualprojectpartb`.`trainerscourses` (`trid`, `cid`) VALUES ("
        };
        try {

            //Get Connection to localhost server
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/individualprojectpartb?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Athens", "root", "1234");

            //Create Statment
            Statement st = con.createStatement();

            int i = Integer.parseInt(menuInput) - 1; // converting input from sting to int
            st.executeUpdate(insertList[i] + tableInserts(menuInput) + ")"); // we call tableInserts function to create the rest of the query depending on the table
            System.out.println("You have sucsessfully updated the table!");

            // Closing connection to database
            st.close();
            con.close();
            insertMenu();
        } catch (SQLException ex) {
            System.out.println("Exception connecting to database:" + ex + "\n");
            mainMenu();
        }
    }

    public static String tableInserts(String menuInput) {
        String[] selectList = {
            /*q1*/"SELECT * FROM `individualprojectpartb`.`trainer`;",
            /*q2*/ "SELECT * FROM `individualprojectpartb`.`student`;",
            /*q3*/ "SELECT * FROM `individualprojectpartb`.`course`;",
            /*q4*/ "SELECT * FROM `individualprojectpartb`.`assigment`;",
            /*q5*/ "SELECT * FROM `individualprojectpartb`.`studentsscourses`;",
            /*q6*/ "SELECT * FROM `individualprojectpartb`.`trainerscourses`;"
        };

        String result = "";
        try {
            // Get Connection to localhost server
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/individualprojectpartb?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Athens", "root", "1234");

            // Create statement
            Statement st = con.createStatement();

            // Using statment to get table collums through metadata
            int i = Integer.parseInt(menuInput);
            ResultSet rs = st.executeQuery(selectList[i - 1]);
            ResultSetMetaData md = rs.getMetaData();
            int colNumber = md.getColumnCount();

            for (int j = 2; j <= colNumber; j++) {
                String check = md.getColumnTypeName(j); // getting colum number and checking for type of data

                switch (check.toLowerCase()) { // switch for input validation
                    case ("varchar"):
                        System.out.println("Insert " + md.getColumnName(j) + " :");
                        result += "'" + sc.next() + "',";
                        break;
                    case ("date"):
                        System.out.println("Insert " +md.getColumnName(j) +" like YYYY-MM-DD :");
                        result += "'" + sc.next() + "',";
                        break;
                    default:
                        System.out.println("Insert " + md.getColumnName(j) + " :");
                        result += " " + sc.next() + " ,";
                        break;
                }

            }
            result = result.substring(0, (result.length()) - 1); // delete the lase comma of the above created string
            // Closing connection to database
            st.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println("Exception connecting to database:" + ex + "\n");
            mainMenu();
        }

        return (result); // created half string to use to above queries
    }
}
